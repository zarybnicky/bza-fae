{-# LANGUAGE ScopedTypeVariables #-}
module RBCTest where

import Control.Monad.Catch (MonadMask, try)
import Control.Monad.State (runState)
import Data.ByteString.Char8 (pack)
import RBC
import Test.Tasty (testGroup)
import Test.Tasty.HUnit (assertEqual, assertFailure, testCase)


unitTests = testGroup "RBC unit tests"
    [ testCase "Reports unknown validator" $ testReportsUnknownValidator
     ,testCase "Rejects its own message" $ testRejectsItsOwnMessage
     ,testCase "Broadcasts the input message" $ testBroadcastsInput
     ,testCase "Echoes Val's" $ testEchoesVals
     ,testCase "Collects echoes" $ testCollectsEchoes
     ,testCase "Fails to parse improperly built proofs" testFailsToParseImproperlyBuiltProofs
     ,testCase "Ignores invalid proofs" $ testIgnoresInvalidProofs
     ,testCase "Collects messages from distinct validators" $ testCollectsMessagesFromDistinctValidators
     ,testCase "Stores echoes" $ testStoresEchoes
     ,testCase "Does not re-broadcast Ready" $ testDoesNotReBroadcastReady
     ,testCase "Broadcasts Ready after receiving matching Ready" $ testBroadcastsReadyAfterReceivingMatchingReady
     ,testCase "Does not broadcast mismatching Ready" $ testDoesNotBroadcastMismatchingReady
     ,testCase "Outputs the message after the sufficient number of inputs" $ testOutputsAfterSufficientInput ]

dummyProof = ((pack "proof", pack "root", pack "leaf"), 1)
validRoot = pack "12e4be7a7baa8ac94314b4287242703626e6c84f5cedf41dd885501ab6300c62"
-- A proof for the part "A mes" of the message "A message" in the (2, 2) scheme.
validProof = ((pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL@e9d78561cec60afa5eaea90cf124de253ef37db5f90ed5215b9071e5e2f9ecf9\NUL\NUL\NUL\NUL\NUL\NUL\NUL@97158552bdd5807dd9a2d23eacd8cce86fa78441f6158b92ad430b4e1e1456de\NUL\NUL\NUL\NUL\NUL\NUL\NUL\NUL@23c9175cfa9c462a1b2ceb369f0b0e8f4158ccfa59ae111eb0be4a5c7d04ae27\NUL\NUL\NUL\NUL\NUL\NUL\NUL@44f7e1bf5f0eaab0030745018dc52c0d940644756b7d64ef0bcec7be9c809212\NUL", validRoot, pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\t\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX\168\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX\239\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX\223\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\173\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH\170\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL'\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\232\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STXR\NUL\NUL\NUL\NUL\NUL\NUL\NUL\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX\245"), 9)
-- Same message, second data part.
secondValidProof = ((pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL@97158552bdd5807dd9a2d23eacd8cce86fa78441f6158b92ad430b4e1e1456de\NUL\NUL\NUL\NUL\NUL\NUL\NUL@e9d78561cec60afa5eaea90cf124de253ef37db5f90ed5215b9071e5e2f9ecf9\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL@23c9175cfa9c462a1b2ceb369f0b0e8f4158ccfa59ae111eb0be4a5c7d04ae27\NUL\NUL\NUL\NUL\NUL\NUL\NUL@44f7e1bf5f0eaab0030745018dc52c0d940644756b7d64ef0bcec7be9c809212\NUL", validRoot, pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\t\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH\DC2\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX\193\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETXT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\245\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX\225\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX\216\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOHo\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL@\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH\136"), 9)
-- Same message, first parity part.
thirdValidProof = ((pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL@8c901ed26dd7f195a83f96cf42de98c99a04ed2d4f8cc919d6cbf03efb2825b0\NUL\NUL\NUL\NUL\NUL\NUL\NUL@cc3dee89600e54b64eb6c558f5ed8aac7f4ecff570f9954d391b0ab069c155f9\NUL\NUL\NUL\NUL\NUL\NUL\NUL\NUL@44f7e1bf5f0eaab0030745018dc52c0d940644756b7d64ef0bcec7be9c809212\NUL\NUL\NUL\NUL\NUL\NUL\NUL@23c9175cfa9c462a1b2ceb369f0b0e8f4158ccfa59ae111eb0be4a5c7d04ae27\SOH", validRoot, pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\t\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETXy\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX\147\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX\201\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH=\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ESC\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX\140\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH\246\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX+\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ETX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\ESC"), 9)
-- Same message, second parity part.
fourthValidProof = ((pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL@cc3dee89600e54b64eb6c558f5ed8aac7f4ecff570f9954d391b0ab069c155f9\NUL\NUL\NUL\NUL\NUL\NUL\NUL@8c901ed26dd7f195a83f96cf42de98c99a04ed2d4f8cc919d6cbf03efb2825b0\SOH\NUL\NUL\NUL\NUL\NUL\NUL\NUL@44f7e1bf5f0eaab0030745018dc52c0d940644756b7d64ef0bcec7be9c809212\NUL\NUL\NUL\NUL\NUL\NUL\NUL@23c9175cfa9c462a1b2ceb369f0b0e8f4158ccfa59ae111eb0be4a5c7d04ae27\SOH", validRoot, pack "\NUL\NUL\NUL\NUL\NUL\NUL\NUL\t\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH\227\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETXe\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX>\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOH\133\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\SOHR\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\ETX@\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX}\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EM\NUL\NUL\NUL\NUL\NUL\NUL\NUL\EOT\NUL\NUL\NUL\NUL\NUL\NUL\NUL\STX\NUL\NUL\NUL\NUL\NUL\NUL\STX\171"), 9)
validProofs = [validProof, secondValidProof, thirdValidProof, fourthValidProof]
invalidProof = let ((p, root, _), size) = validProof in ((p, root, pack "sage\NUL"), size)

testReportsUnknownValidator = do
    let (out, _) = runState (receive (Input $ pack "A message") 5) (setup 4 0)
    shouldbeError <- try out
    case shouldbeError of
        Right o -> assertFailure $ "Did not report unknown validator, but returned: " ++ show o
        Left (UnknownValidator _) -> return ()
        Left e -> assertFailure $ "Did not report unknown validator, but raised: " ++ show e

testRejectsItsOwnMessage = do
    let (out, _) = runState (receive (Echo dummyProof) 0) (setup 1 0)
    shouldbeError <- try out
    case shouldbeError of
        Right o -> assertFailure $ "Did not reject its own message, but returned: " ++ show o
        Left (OwnMessageError _) -> return ()
        Left e -> assertFailure $ "Did not reject its own message, but raised: " ++ show e

testBroadcastsInput = do
    mapM_ testBroadcastsInput' [(2, 0), (2, 1), (3, 0), (3, 1), (3, 2), (4, 0), (4, 1), (4, 2)]

testBroadcastsInput' (n, self) = do
    let (out, _) = runState (receive (Input $ pack "A message") (head [v | v <- [0..n-1], v /= self])) (setup n self)
    broadcast <- out
    case broadcast of
        Broadcast messages -> assertBroadcastsInput messages n self
        o -> assertFailure $ "Did not broadcast the expected message: " ++ show o

assertBroadcastsInput messages n self = do
    assertEqual "Did not broadcast to all validators" [v | v <- [0..n-1], v /= self] (map (\(_, v) -> v) messages)
    mapM_ assertMessage messages where
        assertMessage (Val (_, size), _) = assertEqual "Did not broadcast the correct message size: " 9 size
        assertMessage msg = assertFailure $ "Broadcasted not `Val`: " ++ show msg

testEchoesVals = do
    let (out, _) = runState (receive (Val dummyProof) 1) (setup 4 0)
    Broadcast messages <- out
    assertEqual "Did not broadcast correct messages to all validators" (map (\v -> (Echo dummyProof, v)) [1, 2, 3]) messages

testCollectsEchoes = do
    let (out, _) = runState (receive (Echo secondValidProof) 1) (setup 4 0)
    result <- out
    case result of
        StoreEcho (proof, validator) -> assertEqual "The echo changed during processing" secondValidProof proof
        o -> assertFailure $ "Did not output the correct echo processing result: " ++ show o

testCollectsMessagesFromDistinctValidators = do
    let initialState = (setup 4 0) {
        getEcho = [(1, secondValidProof)]
    }
    let (out, _) = runState (receive (Echo secondValidProof) 1) initialState
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not ignore the repeated message but returned: " ++ show o

testFailsToParseImproperlyBuiltProofs = do
    let (out, _) = runState (receive (Echo dummyProof) 1) (setup 4 0)
    maybeResult <- try out
    case maybeResult of
        Left (e :: RBCError) -> return ()
        Right o -> assertFailure $ "Did not complain about the improperly coded proof but returned: " ++ show o

testIgnoresInvalidProofs = do
    let (out, _) = runState (receive (Echo invalidProof) 1) (setup 4 0)
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not ignore invalid proof but returned: " ++ show o

testStoresEchoes = do
    let (out, stateAfterOneEcho) = runState (storeEcho secondValidProof 1) (setup 4 0)
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not just store the echo but returned: " ++ show o

    let (out, stateAfterTwoEchoes) = runState (storeEcho thirdValidProof 2) stateAfterOneEcho
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not just store the echo but returned2: " ++ show o
    print stateAfterTwoEchoes
    let (out, stateAfterThreeEchoes) = runState (storeEcho fourthValidProof 3) stateAfterTwoEchoes
    result <- out
    case result of
        StoreMessage (message, Broadcast messages) ->
            assertEqual "Did not broadcast the correct messages" [(Ready validRoot, v) | v <- [1, 2, 3]] messages >>
            assertEqual "Did not record the correct message" (pack "A message") message
        o -> do
          print stateAfterThreeEchoes
          print o
          assertFailure $ "Did not interpolate shards but returned: " ++ show o

    assertEqual "Did not store all echoes correctly" (zip [1, 2, 3] [secondValidProof, thirdValidProof, fourthValidProof]) (getEcho stateAfterThreeEchoes)

buildStateWithTwoEchoes = do
    let (out, s) = runState (storeEcho secondValidProof 1) (setup 4 0)
    _ <- out
    let (out, state) = runState (storeEcho thirdValidProof 2) s
    _ <- out
    return state

testDoesNotReBroadcastReady = do
    state <- buildStateWithTwoEchoes

    let (_, stateAfterReadySent) = runState markReadySent state
    let (maybeOut, _) = runState (storeEcho fourthValidProof 3) stateAfterReadySent
    out <- maybeOut
    case out of
        None -> return ()
        _ -> assertFailure $ "Did not ignore yet another Ready but returned: " ++ show out

testBroadcastsReadyAfterReceivingMatchingReady = do
    let (out, stateAfterOneReady) = runState (storeReady (pack "A root") 1) (setup 4 0)
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not just store Ready but returned: " ++ show o

    let (out, stateAfterTwoReadies) = runState (storeReady (pack "A root") 2) stateAfterOneReady
    result <- out
    case result of
        Broadcast messages -> assertEqual "Did not broadcast the correct messages" (map (\v -> (Ready (pack "A root"), v)) [1, 2, 3]) messages
        o -> assertFailure $ "Did not broadcast messages but returned:  " ++ show o

    let (_, afterReadySent) = runState markReadySent stateAfterTwoReadies
    let (out, _) = runState (storeReady (pack "A root") 3) afterReadySent
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not ignore yet another Ready but returned: " ++ show o

testDoesNotBroadcastMismatchingReady = do
    let root = pack "A root"
    let mismatchingRoot = pack "A mismatching root"

    let state = (setup 4 0) {
        getReady = [
             (1, root)
            ,(2, root)
            ,(1, mismatchingRoot)
        ]
    }
    let (out, _) = runState (storeReady mismatchingRoot 2) state
    result <- out
    case result of
        None -> return ()
        o -> assertFailure $ "Did not ignore mismatching Ready but returned: " ++ show o

testOutputsAfterSufficientInput = do
    -- The output is expected after at least 2f + 1 Ready and at least N - 2f Echo.

    -- enough of Ready but not enough of Echo
    let state = (setup 4 0) {
         getEcho = []
        ,getReady = [
             (1, validRoot)
            ,(2, validRoot)
            ,(3, validRoot)
        ]
        ,getReadySent = True
    }
    let (out, _) = runState (storeEcho secondValidProof 1) state
    result <- out
    case result of
        None -> return ()
        o    -> assertFailure $ "Returned unexpected output: " ++ show o

    let (out, _) = runState (storeReady validRoot 1) state
    result <- out
    case result of
        None -> return ()
        o    -> assertFailure $ "Returned unexpected output: " ++ show o

    -- enough of Echo but not enough of Ready
    let state = (setup 4 0) {
         getEcho = [
            (1, secondValidProof)
         ]
        ,getReady = [
            (1, validRoot)
        ]
        ,getReadySent = True
    }
    let (out, _) = runState (storeEcho thirdValidProof 2) state
    result <- out
    case result of
        None -> return ()
        o    -> assertFailure $ "Returned unexpected output: " ++ show o

    let (out, _) = runState (storeReady validRoot 2) state
    result <- out
    case result of
        None -> return ()
        o    -> assertFailure $ "Returned unexpected output: " ++ show o

    -- enough of Echo and Ready
    let state = (setup 4 0) {
         getEcho = [
             (1, secondValidProof)
            ,(2, thirdValidProof)
         ]
        ,getReady = [
              (1, validRoot)
             ,(2, validRoot)
             ,(3, validRoot)
        ]
        ,getReadySent = True
    }
    let (_, withMessage) = runState (storeMessage $ pack "A message") state
    let (out, _) = runState (storeEcho fourthValidProof 3) withMessage
    result <- out
    case result of
        Output msg -> assertEqual "Did not output the correct message" (pack "A message") msg
        o    -> assertFailure $ "Did not output the message after storing echo but returned: " ++ show o

    let (out, _) = runState (storeReady validRoot 2) withMessage
    result <- out
    case result of
        Output msg -> assertEqual "Did not output the correct message" (pack "A message") msg
        o    -> assertFailure $ "Did not output the message after storing Ready but returned: " ++ show o
