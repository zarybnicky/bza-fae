import           Test.Tasty     (TestTree, defaultMain, testGroup)

import           RBCTest

main = defaultMain $ testGroup "Tests" [RBCTest.unitTests]
