body :: FaeTX String
body = return "Hello, World!"

